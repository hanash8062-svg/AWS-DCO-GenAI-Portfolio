from pathlib import Path
import re

# 이 스크립트는 교육용 로그(server01.log~server04.log)를 분석합니다.
# 실제 서버, 실제 네트워크, 실제 AWS 환경에는 접속하지 않습니다.

BASE_DIR = Path(__file__).resolve().parent
LOG_FILES = ["server01.log", "server02.log", "server03.log", "server04.log"]

# 로그 한 줄의 시작을 판별하는 정규식입니다.
# server01: 2026-07-06 00:32:17 server01 ERROR ...
# server02: Jul 06 02:16:06 server02 ERROR ...
# server03: [06/Jul/2026:01:42:05] server03 ERROR ...
# server04: 03:32:13.800 server04 ERROR ...
ENTRY_START_RE = re.compile(
    r"""^(
        \d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2} |
        [A-Z][a-z]{2}\s+\d{2}\s+\d{2}:\d{2}:\d{2} |
        \[\d{2}/[A-Z][a-z]{2}/\d{4}:\d{2}:\d{2}:\d{2}\] |
        \d{2}:\d{2}:\d{2}\.\d{3}
    )\s+(server\d+)\s+(INFO|ERROR)\s+(.*)$""",
    re.VERBOSE,
)

CRC_RE = re.compile(r"\bcrc\s+error\b", re.IGNORECASE)
LINK_RE = re.compile(r"\blink\s+down\b", re.IGNORECASE)


def parse_records(text):
    """
    여러 줄에 걸친 로그를 하나의 record로 묶습니다.
    새 timestamp/server/level이 나오면 새 record로 판단합니다.
    """
    records = []
    current = None

    for raw_line in text.splitlines():
        line = raw_line.rstrip("\n")
        match = ENTRY_START_RE.match(line)

        if match:
            if current:
                records.append(current)

            timestamp, server, level, message = match.groups()
            current = {
                "timestamp": timestamp.strip(),
                "server": server.strip(),
                "level": level.strip(),
                "message": message.strip(),
                "raw": line,
            }
        else:
            # 들여쓰기된 상세 설명은 직전 ERROR/INFO 로그에 붙입니다.
            if current:
                current["message"] += " " + line.strip()
                current["raw"] += "\n" + line

    if current:
        records.append(current)

    return records


def analyze_one_file(path):
    """
    한 서버 로그에서 ERROR 레벨의 CRC error와 Link Down만 셉니다.
    INFO 레벨의 'CRC error recovered', 'no CRC error found'는 실제 장애로 세지 않습니다.
    """
    text = path.read_text(encoding="utf-8", errors="ignore")
    records = parse_records(text)

    crc_count = 0
    link_down_count = 0

    for record in records:
        # 실제 장애 이벤트는 ERROR 레벨만 집계합니다.
        if record["level"] != "ERROR":
            continue

        normalized_message = re.sub(r"\s+", " ", record["message"])

        if CRC_RE.search(normalized_message):
            crc_count += 1

        if LINK_RE.search(normalized_message):
            link_down_count += 1

    return {
        "server": path.stem,
        "crc_error": crc_count,
        "link_down": link_down_count,
        "records": len(records),
    }


def print_markdown_table(results):
    total_crc = sum(row["crc_error"] for row in results)
    total_link = sum(row["link_down"] for row in results)

    print("| 서버 | CRC error | Link Down |")
    print("|---|---:|---:|")
    for row in results:
        print(f"| {row['server']} | {row['crc_error']} | {row['link_down']} |")
    print(f"| **합계** | **{total_crc}** | **{total_link}** |")


def main():
    results = []

    for file_name in LOG_FILES:
        path = BASE_DIR / file_name

        if not path.exists():
            print(f"[경고] 파일을 찾을 수 없습니다: {path}")
            continue

        results.append(analyze_one_file(path))

    print("\n[최종 2차 분석 결과: ERROR 레벨 기준]")
    print_markdown_table(results)


if __name__ == "__main__":
    main()
